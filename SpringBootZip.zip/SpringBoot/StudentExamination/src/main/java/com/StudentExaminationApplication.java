package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.dao.StudentRepository;
import com.model.Student;

@SpringBootApplication
public class StudentExaminationApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentExaminationApplication.class, args);
	}

}
