package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dao.StudentNotFoundException;
import com.dao.StudentRepository;
import com.model.Student;
import com.model.StudentErrorResponse;

@RestController
public class AdminRestController {
	
//	@ExceptionHandler
//	public ResponseEntity<StudentErrorResponse> handleException(StudentNotFoundException ex){
//		
//		StudentErrorResponse error = new StudentErrorResponse();
//				
//		error.setStatus_code(HttpStatus.NOT_FOUND.value());
//		error.setMessage(ex.getMessage());
//		error.setTimestramp(System.currentTimeMillis());
//		return new ResponseEntity(error,HttpStatus.NOT_FOUND);
//	}
//	
//	@ExceptionHandler
//	public ResponseEntity<StudentErrorResponse> handleException(Exception ex){
//		
//		StudentErrorResponse error = new StudentErrorResponse();
//		
//		error.setStatus_code(HttpStatus.BAD_REQUEST.value());
//		error.setMessage(ex.getMessage());
//		error.setTimestramp(System.currentTimeMillis());
//		return new ResponseEntity(error,HttpStatus.BAD_REQUEST);
//	}

	@Autowired
	StudentRepository stuRep;

	@PostMapping("/addstu")
	public Student addStudent(@RequestBody Student s) {
		Student st = new Student();
		st.setFname(s.getFname());
		st.setLname(s.getLname());
		stuRep.save(st);
		System.out.println("Student added.....");
		return st;
	}

	@GetMapping("/students")
	public List<Student> getAllStudents() {
		List<Student> list = (List<Student>) stuRep.findAll();
		return list;
	}

	@DeleteMapping("/delete/{sid}")
	public void deleteStudent(@PathVariable("sid") int sid) {
		Student st = new Student();
		st = stuRep.findById(sid).get();
		stuRep.deleteById(sid);
		System.out.println("student deleted..");
	}

	@PutMapping("/update/{sid}")
	public Student updateStudent(@RequestBody Student s, @PathVariable("sid") int sid) {
		Student st = new Student();
		Optional<Student> stu = stuRep.findById(sid);
		st = stu.get();
		st.setFname(s.getFname());
		st.setLname(s.getLname());
		stuRep.save(st);
		System.out.println("student updated");
		return st;
	}

	@GetMapping("/student/{sid}")
	public Student getStuByid(@PathVariable("sid") int sid) {
//		Optional<Student> stu = stuRep.findById(sid);
//		s = stu.get();
//		Student s = new Student();
//		return s;
//		OR
		Student stu = stuRep.findById(sid).get();

		return stu;
	}
}