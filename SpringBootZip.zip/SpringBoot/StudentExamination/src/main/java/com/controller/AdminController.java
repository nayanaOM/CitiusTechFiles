package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dao.QuestionRepository;
import com.dao.StudentRepository;
import com.model.Question;
import com.model.Student;

@Controller
public class AdminController {

	@Autowired
	StudentRepository stuRepo;

	@Autowired
	QuestionRepository queRepo;

	@RequestMapping("/home")
	public String home() {
		return "home";
	}

	@RequestMapping("/admin")
	public String admin() {
		return "admin";
	}

	@RequestMapping("/addstudent")
	public String addStud() {
		return "addstudent";

	}

	@RequestMapping("/added")
	public String addStudent(@ModelAttribute Student s) {
		Student stu = new Student();
		stu.setFname(s.getFname());
		stu.setLname(s.getLname());
		stuRepo.save(stu);
		System.out.println("added...");
		return "added";

	}

	@RequestMapping("/updatestudent")
	public String updateStudent() {
		return "updatestudent";

	}

	@RequestMapping("/updated")
	public String update(@ModelAttribute Student s) {
		Optional<Student> st = stuRepo.findById(s.getSid());
		Student stu = st.get();
		stu = new Student();
		stu.setFname(s.getFname());
		stu.setLname(s.getLname());
		stuRepo.save(stu);

		return "updatequesuccess";
	}

	@RequestMapping("/getstudents")
	public String getAllStudents(Model m) {
		List<Student> list = (List<Student>) stuRepo.findAll();
		m.addAttribute("students", list);
		return "getallstudents";
	}

	@RequestMapping("/deletestudent")
	public String deleteStu() {
		return "deletestudent";

	}

	@RequestMapping("/deleted")
	public String deleteStudent(@RequestParam("sid") int sid) {
		stuRepo.deleteById(sid);
		return "deletesuccess";
	}

	@RequestMapping("/getstudent")
	public String getStuByID() {
		return "getstudent";

	}

	@RequestMapping("/displaystudent")
	public String getStudentByID(@RequestParam("sid") int sid, Model m) {
		Optional<Student> stu = stuRepo.findById(sid);
		Student st = stu.get();
		m.addAttribute("student", st);
		return "displaystudent";
	}

	@RequestMapping("/getstudentbyname")
	public String getStuByName() {
		return "getstudentbyname";
	}

	@RequestMapping("/displaystudentbyname")
	public String displayStuByName(@RequestParam("fname") String fname, Model m) {
		Student stu = stuRepo.findByFname(fname);

		m.addAttribute("studentByName", stu);
		return "displaystudentByName";
	}

//	......................................................................

	@RequestMapping("/addQuestion")
	public String addQue() {
		return "addQuestion";
	}

	@RequestMapping("/queadded")
	public String addQuestion(@ModelAttribute Question q) {
		Question que = new Question(q.getQid(), q.getQue(), q.getOp1(), q.getOp2(), q.getOp3(), q.getCorectAns());
		queRepo.save(que);
		return "queadded";
	}

	@RequestMapping("/updateQuestion")
	public String updateQue() {
		return "updateQuestion";
	}

	@RequestMapping("/queupdated")
	public String updateQueuestion(@ModelAttribute Question q) {
//		Question qn = new Question();
//		Optional<Question> que = queRepo.findById(q.getQid());
//		qn=que.get();
//		qn.setQid(q.getQid());
//		qn.setQue(q.getQue());
//		qn.setOp1(q.getOp1());
//		qn.setOp2(q.getOp2());
//		qn.setOp3(q.getOp3());
//		qn.setCorectAns(q.getCorectAns());
//		queRepo.save(qn);

//		OR
		Optional<Question> que = queRepo.findById(q.getQid());
		Question qn = que.get();
		qn = new Question(q.getQid(), q.getQue(), q.getOp1(), q.getOp2(), q.getOp3(), q.getCorectAns());
		qn.setCorectAns(q.getCorectAns());

		queRepo.save(qn);
		return "updatequesuccess";
	}

	@RequestMapping("/deleteQuestion")
	public String deleteQue() {
		return "deleteQuestion";

	}

	@RequestMapping("/quedeleted")
	public String deleteQuestion(@RequestParam("qid") int qid) {
		Optional<Question> que = queRepo.findById(qid);
		Question q = que.get();
		queRepo.delete(q);
		return "quedeletesuccess";
	}
}
