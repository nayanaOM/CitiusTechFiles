package com;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
//@Setter
//@Getter
public class StudentReq {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int sid;

	@NotNull(message = "cannot be null")
	private String sname;

	@Min(18)
	@Max(25)
	private int sage;

	@Pattern(regexp = "^\\\\d{10}$")
	private String phone;
	
	@Email
	private String email;

	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public int getSage() {
		return sage;
	}
	public void setSage(int sage) {
		this.sage = sage;
	}
	public String getEmail() {
		return email;
	}
	public void setSaddress(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}

}