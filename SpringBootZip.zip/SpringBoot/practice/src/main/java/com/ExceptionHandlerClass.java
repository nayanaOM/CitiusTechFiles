package com;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;

public class ExceptionHandlerClass {

	@ExceptionHandler
	public ResponseEntity<Student> handler(MethodArgumentNotValidException ex){
		
		return null;
		
	}
}
