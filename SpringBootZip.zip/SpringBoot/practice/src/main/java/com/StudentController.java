package com;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class StudentController {

	@Autowired
	StudentRepository strepo;

//	@PostMapping("/add")
//	public Student addStu(@RequestBody Student st) {
//		Student s = new Student(st.getSname(), st.getSage(), st.getPhone(), st.getEmail());
//		strepo.save(s);
//		return st;
//	}

	@PostMapping("/add")
	public ResponseEntity<Student> addStu(@RequestBody @Valid Student st) {
		Student s = new Student(st.getSname(), st.getSage(), st.getPhone(), st.getEmail());
		strepo.save(s);
		return new ResponseEntity<Student>(s, HttpStatus.CREATED);
	}

//	@PutMapping("/update/{sid}")
//	public Student updatestu(@RequestBody Student st, @PathVariable("sid") int sid) {
//		Student s = strepo.findById(sid).get();
//		s.setSname(st.getSname());
//		s.setSage(st.getSage());
//		s.setPhone(st.getPhone());
//		s.setEmail(st.getEmail());
////		s = new Student(st.getSname(),st.getSage(),st.getPhone(),st.getEmail()); Don't do this way
//		strepo.save(s);
//		return st;
//
//	}

	@PutMapping("/update/{sid}")
	public ResponseEntity<Student> updatestu(@RequestBody Student st, @PathVariable("sid") int sid) {
		Student s = strepo.findById(sid).get();
		s.setSname(st.getSname());
		s.setSage(st.getSage());
		s.setPhone(st.getPhone());
		s.setEmail(st.getEmail());
		strepo.save(s);
		return new ResponseEntity<Student>(s, HttpStatus.OK);

	}

//	@DeleteMapping("/delete/{sid}")
//	public void deleteStu(@PathVariable("sid") int sid) {
//		strepo.deleteById(sid);
//	}

//	To return only HttpStatusCode
//	@DeleteMapping("/delete/{sid}")
//	public ResponseEntity<Student>  deleteStu(@PathVariable("sid") int sid) {
//		strepo.deleteById(sid);
//		return new ResponseEntity<Student>(HttpStatus.OK);
//	}

//	To return deleted object with HttpStatusCode
	@DeleteMapping("/delete/{sid}")
	public ResponseEntity<Student> deleteStu(@PathVariable("sid") int sid) {
		Student s = strepo.findById(sid).get();
		strepo.deleteById(sid);
		return new ResponseEntity<Student>(s, HttpStatus.ACCEPTED);
	}

//	@GetMapping("students")
//	public List<Student> getAllStu() {
//		List<Student> list = strepo.findAll();
////		no need of .get() while using findall
//		return list;
//	}

	@GetMapping("students")
	public ResponseEntity<List<Student>> getAllStu() {
		List<Student> list = strepo.findAll();
		return new ResponseEntity<List<Student>>(list,HttpStatus.ACCEPTED);
	}

//	@GetMapping("/student/{sid}")
//	public Student getById(@PathVariable("sid") int sid) {
//		Student s = strepo.findById(sid).get();
//		return s;
//	}
	
	@GetMapping("/student/{sid}")
	public ResponseEntity<Student> getById(@PathVariable("sid") int sid) {
		Student s = strepo.findById(sid).get();
		return new ResponseEntity<Student>(s,HttpStatus.ACCEPTED);
	}

	
}
