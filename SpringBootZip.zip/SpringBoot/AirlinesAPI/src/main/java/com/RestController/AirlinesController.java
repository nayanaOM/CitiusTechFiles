package com.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.AirlinesRepository;
import com.model.Flight;

import jakarta.validation.Valid;

@RestController
//@CrossOrigin(origins = "http://localhost:8080")
public class AirlinesController {

	@Autowired
	AirlinesRepository airRepo;

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handler(MethodArgumentNotValidException ex) {

		Map<String, String> errorMap = new HashMap<>();
//		for (int i = 0; i < ex.getFieldErrorCount(); i++) {
//			errorMap.put(ex.getBindingResult().getFieldError().getField(), ex.getBindingResult().getFieldError().getDefaultMessage());
//			errorMap.putAll(errorMap);
//			System.out.println(errorMap);
//		}
//		return errorMap;
		ex.getBindingResult().getFieldErrors().forEach(errors -> {
			errorMap.put(errors.getField(), errors.getDefaultMessage());
		});
		return errorMap;
	}

	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/add")
	public ResponseEntity<Flight> addFlight(@RequestBody @Valid Flight fl) {
		Flight f = new Flight(fl.getFlightId(), fl.getFlightName(), fl.getOrigin(), fl.getDestination(),
				fl.getDateOfDeparture(), fl.getDateOfArrival(), fl.getPriceOfBusiness(), fl.getPriceOfEconomic());
		airRepo.save(f);
		return new ResponseEntity<Flight>(f, HttpStatus.CREATED);
	}

	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/update/{flightId}")
	public ResponseEntity<Flight> updateFlight(@RequestBody @Valid Flight fl, @PathVariable("flightId") int flightId) {
		Flight f = airRepo.findById(flightId).get();

		f.setFlightName(fl.getFlightName());
		f.setOrigin(fl.getOrigin());
		f.setDestination(fl.getDestination());
		f.setDateOfDeparture(fl.getDateOfDeparture());
		f.setDateOfArrival(fl.getDateOfArrival());
		f.setPriceOfBusiness(fl.getPriceOfBusiness());
		f.setPriceOfEconomic(fl.getPriceOfEconomic());
		airRepo.save(f);
		return new ResponseEntity<Flight>(f, HttpStatus.ACCEPTED);
	}

	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/delete/{flightId}")
	public void deleteFlight(@PathVariable("flightId") int flightId) {
		airRepo.deleteById(flightId);
	}

	@GetMapping("/flight/{flightId}")
	public ResponseEntity<Flight> getFlight(@PathVariable("flightId") int flightId) {
		Flight f = airRepo.findById(flightId).get();
		return new ResponseEntity<Flight>(f, HttpStatus.OK);
	}

	@GetMapping("/flights")
	public List<Flight> getAllFlights() {
		List<Flight> list = airRepo.findAll();
		return list;
	}
//	@GetMapping("/flights")
//	public ResponseEntity<List<Flight>> getAllFlights() {
//		List<Flight> list = airRepo.findAll();
//		return new ResponseEntity<List<Flight>>(list, HttpStatus.ACCEPTED);
//	}

	@GetMapping("/origin/{origin}")
	public ResponseEntity<List<Flight>> findByOrigin(@PathVariable("origin") String origin) {
		List<Flight> list = airRepo.findByOrigin(origin);
		return new ResponseEntity<List<Flight>>(list, HttpStatus.OK);
	}

//	@GetMapping("/date/{dateOfDeparture}")
//	public ResponseEntity<List<Flight>> getFlightsByDate(@PathVariable("dateOfDeparture") String dateOfDeparture){
//		List<Flight> list = airRepo.findByDateOfDeparture(dateOfDeparture);
//		return new ResponseEntity<List<Flight>>(list,HttpStatus.ACCEPTED);
//	}

	@GetMapping("/date/{dateOfDeparture}")
	public ResponseEntity<List<Flight>> getFlightsByDate(@PathVariable("dateOfDeparture") String dateOfDeparture) {
		List<Flight> list = airRepo.getFlightsByDate(dateOfDeparture);
		return new ResponseEntity<List<Flight>>(list, HttpStatus.ACCEPTED);
	}

}
