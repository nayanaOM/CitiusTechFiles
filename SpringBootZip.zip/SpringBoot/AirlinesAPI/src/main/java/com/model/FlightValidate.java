package com.model;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//@Data
//@AllArgsConstructor(staticName = "build")
//@NoArgsConstructor
public class FlightValidate {
//	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
//	private int flightId;
//	@NotBlank(message="Flight Name shouldn't be blank")
//	private String flightName;
//	@NotBlank(message="Flight Name shouldn't be blank")
//	private String origin;
//	@NotBlank(message="Flight Name shouldn't be blank")
//	private String destination;
//	@NotNull(message="Flight Date Of Departure shouldn't be empty")
//	private String dateOfDeparture;
//	@NotNull(message="Flight Date Of Arrival shouldn't be empty")
//	private String dateOfArrival;
//	@NotNull
//	private float priceOfBusiness;
//	@NotNull
//	private float priceOfEconomic;
//
//	public int getFlightId() {
//		return flightId;
//	}
//
//	public void setFlightId(int flightId) {
//		this.flightId = flightId;
//	}
//
//	public String getFlightName() {
//		return flightName;
//	}
//
//	public void setFlightName(String flightName) {
//		this.flightName = flightName;
//	}
//
//	public String getOrigin() {
//		return origin;
//	}
//
//	public void setOrigin(String origin) {
//		this.origin = origin;
//	}
//
//	public String getDestination() {
//		return destination;
//	}
//
//	public void setDestination(String destination) {
//		this.destination = destination;
//	}
//
//	public String getDateOfDeparture() {
//		return dateOfDeparture;
//	}
//
//	public void setDateOfDeparture(String dateOfDeparture) {
//		this.dateOfDeparture = dateOfDeparture;
//	}
//
//	public String getDateOfArrival() {
//		return dateOfArrival;
//	}
//
//	public void setDateOfArrival(String dateOfArrival) {
//		this.dateOfArrival = dateOfArrival;
//	}
//
//	public float getPriceOfBusiness() {
//		return priceOfBusiness;
//	}
//
//	public void setPriceOfBusiness(float priceOfBusiness) {
//		this.priceOfBusiness = priceOfBusiness;
//	}
//
//	public float getPriceOfEconomic() {
//		return priceOfEconomic;
//	}
//
//	public void setPriceOfEconomic(float priceOfEconomic) {
//		this.priceOfEconomic = priceOfEconomic;
//	}

}
