package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

//@Data
//@AllArgsConstructor(staticName = "build")
//@NoArgsConstructor
@Entity
@Table(name = "flight")
public class Flight {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int flightId;
	@NotBlank(message = "Can't null")
	private String flightName;
	@NotBlank(message = "Can't null")
	private String origin;
	private String destination;
	@NotNull
	private String dateOfDeparture;
	private String dateOfArrival;
	private float priceOfBusiness;
	private float priceOfEconomic;

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDateOfDeparture() {
		return dateOfDeparture;
	}

	public void setDateOfDeparture(String dateOfDeparture) {
		this.dateOfDeparture = dateOfDeparture;
	}

	public String getDateOfArrival() {
		return dateOfArrival;
	}

	public void setDateOfArrival(String dateOfArrival) {
		this.dateOfArrival = dateOfArrival;
	}

	public float getPriceOfBusiness() {
		return priceOfBusiness;
	}

	public void setPriceOfBusiness(float priceOfBusiness) {
		this.priceOfBusiness = priceOfBusiness;
	}

	public float getPriceOfEconomic() {
		return priceOfEconomic;
	}

	public void setPriceOfEconomic(float priceOfEconomic) {
		this.priceOfEconomic = priceOfEconomic;
	}

	public Flight(int flightId, String flightName, String origin, String destination, String dateOfDeparture,
			String dateOfArrival, float priceOfBusiness, float priceOfEconomic) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.origin = origin;
		this.destination = destination;
		this.dateOfDeparture = dateOfDeparture;
		this.dateOfArrival = dateOfArrival;
		this.priceOfBusiness = priceOfBusiness;
		this.priceOfEconomic = priceOfEconomic;
	}

	public Flight() {
		super();
	}
	
	

}
