package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exception.Ratingexception;
import com.exception.ResourceNotFoundEx;
import com.model.Rating;
import com.service.RatingServiceImpl;

import jakarta.validation.Valid;

@RestController
public class RatingController {

	@Autowired
	RatingServiceImpl ratingServiceImpl;

	@PostMapping("/save")
	public ResponseEntity<Rating> saveRatings(@RequestBody @Valid Rating rating) {
//		return new ResponseEntity<Rating>(ratingServiceImpl.saveRating(rating), HttpStatus.OK);
		Rating r = ratingServiceImpl.saveRating(rating);
		if (r == null) {
			ResponseEntity.badRequest().build();
//			ResponseEntity.badRequest().body(r);
		}
		return ResponseEntity.status(HttpStatus.CREATED).body(r);
//		return ResponseEntity.of(Optional.of(r));

	}

	@GetMapping("/ratings")
	public ResponseEntity<List<Rating>> getAllRatings() {
		return ResponseEntity.ok(ratingServiceImpl.getAllRatings());
	}

	@GetMapping("/rating/{ratingId}")
	public ResponseEntity<Rating> getRatingByid(@PathVariable int ratingId) {
		return new ResponseEntity<Rating>(ratingServiceImpl.getRating(ratingId), HttpStatus.OK);

//		WAY : 1 FOR SENDING RESPONSE
//		Rating r = ratingServiceImpl.getRating(ratingId);
//		if (r == null) {
//			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
////			throw new ResourceNotFoundEx();
//		} else {
//			return ResponseEntity.of(Optional.of(r)); // here HttpStatus is always OK while sending data
//		}
	}

	@GetMapping("/getuser/{userId}")
	public ResponseEntity<List<Rating>> getRatingByUserid(@PathVariable int userId) {
		return new ResponseEntity<List<Rating>>(ratingServiceImpl.listRatingByUserId(userId), HttpStatus.OK);
//		OR
//		WAY : 2 FOR SENDING RESPONSE
//		List<Rating> list = ratingServiceImpl.listRatingByUserId(userId);
//		if (list.isEmpty()) {
//			return ResponseEntity.notFound().build();
//		} else {
//			return ResponseEntity.ok().body(list); // here we can change HttpStatus while sending data
//			return ResponseEntity.accepted().body(list);

//			NOTE:  ResponseEntity.notFound().body(); and ResponseEntity.noContent().body(); are invalid
//			means .body() is not there for notFound() & noContent()

//	}

	}

	@GetMapping("/hotel/{hotelId}")
	public ResponseEntity<Object> getRatingByHotelId(@PathVariable int hotelId) {
//		return new ResponseEntity(ratingServiceImpl.listRatingsByHotelId(hotelId), HttpStatus.OK);

		try {
			List<Rating> list = ratingServiceImpl.listRatingsByHotelId(hotelId);
			return ResponseEntity.ok(list);
		} catch (ResourceNotFoundEx e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND)
					.body(new Ratingexception(HttpStatus.NOT_FOUND.value(), e.getMessage()));
		}
	}
}