package com.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "HotelDetails")
public class Hotel {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "HotelID")
	private int hotelId;

	@Column(name = "HotelName")
	@NotBlank(message = "HotelName shouldn't be blank")
	@NotNull(message = "HotelName shouldn't be null")
	private String name;

	@NotBlank(message = "HotelLocation shouldn't be blank")
	@NotNull(message = "HotelLocation shouldn't be null")
	@Column(name = "HotelLocation")
	private String location;

	public Hotel(int hotelId, String name, String location) {
		super();
		this.hotelId = hotelId;
		this.name = name;
		this.location = location;
	}

	public Hotel() {
		super();
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Hotel [hotelId=" + hotelId + ", name=" + name + ", location=" + location + "]";
	}

}
