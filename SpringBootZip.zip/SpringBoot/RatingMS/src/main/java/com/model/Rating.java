package com.model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NegativeOrZero;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "RatingDetails")
public class Rating {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "RatingID")
	private int ratingId;

	// id can't have Notblank and NotNull
	
//	NotNullException is applied for this
	@Column(name = "UserID")
	private int userId;

	@Column(name = "HotelID")
	private int hotelId;

	@Max(5)
	@Column(name = "Rating")
	private int rating;

	@Column(name = "Remark")
	private String remark;
	
	@Transient
	@Column(name = "Hotel")
	private Hotel hotel;

	public int getRatingId() {
		return ratingId;
	}

	public void setRatingId(int ratingId) {
		this.ratingId = ratingId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Rating() {
		super();
	}

	public Rating(int ratingId, int userId, int hotelId, int rating, String remark) {
		super();
		this.ratingId = ratingId;
		this.userId = userId;
		this.hotelId = hotelId;
		this.rating = rating;
		this.remark = remark;
	}

	@Override
	public String toString() {
		return "Rating [ratingId=" + ratingId + ", userId=" + userId + ", hotelId=" + hotelId + ", rating=" + rating
				+ ", remark=" + remark + "]";
	}
}
