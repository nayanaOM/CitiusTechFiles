package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exception.NonZeroException;
import com.exception.ResourceNotFoundEx;
import com.model.Rating;
import com.repository.RatingRepository;

@Service
public class RatingServiceImpl implements RatingService {

	@Autowired
	RatingRepository ratingRepository;

	@Override
	public Rating saveRating(Rating rating) {
//		if (rating.getUserId() == 0 || rating.getUserId() < 0 || rating.getHotelId() == 0 || rating.getHotelId() < 0) {
//			throw new NonZeroException();
//		} else {
//			return ratingRepository.save(rating);
//		}
		Rating r = null;
		try {
			r = ratingRepository.save(rating);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return r;
	}

	@Override
	public List<Rating> getAllRatings() {
		return ratingRepository.findAll();
	}

	@Override
	public Rating getRating(int ratingId) {
//		THROWING EXCEPTION
//		return ratingRepository.findById(ratingId).orElseThrow(() -> new ResourceNotFoundEx());

//		OR
//		HANDLING EXCEPTION HERE ONLY. OBSERVE THE RESPONSE
		Rating r = null;
		try {
			r = ratingRepository.findById(ratingId).get();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return r;

	}

	public List<Rating> listRatingByUserId(int userId) {
//		List<Rating> list = ratingRepository.findByUserId(userId);
//		if (list.isEmpty() == true) {
//			throw new ResourceNotFoundEx();
//		} else {
//			return list;
//		}

		List<Rating> list = null;
		try {
			list = ratingRepository.findByUserId(userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<Rating> listRatingsByHotelId(int hotelId) {
//		List<Rating> list = ratingRepository.getByHotelId(hotelId);
		List<Rating> list = ratingRepository.findByHotelId(hotelId);
		if (list.isEmpty() == true) {
			throw new ResourceNotFoundEx();
		} else {
			return list;
		}
	}
}
