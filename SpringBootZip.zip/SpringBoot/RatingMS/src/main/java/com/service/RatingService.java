package com.service;

import java.util.List;

import com.model.Rating;

public interface RatingService {
	Rating saveRating(Rating rating);

	List<Rating> getAllRatings();

	Rating getRating(int ratingId);
}
