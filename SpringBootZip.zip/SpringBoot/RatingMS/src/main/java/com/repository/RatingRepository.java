package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.model.Rating;

@Repository
public interface RatingRepository extends JpaRepository<Rating, Integer> {

//	@Query(value = "select * from rating_details where hotelid=?", nativeQuery = true)
//	List<Rating> getByHotelId(int hotelId);

	List<Rating> findByUserId(int userId);
	List<Rating> findByHotelId(int hotelId);
}
