package com.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionHandlerControllerAdvice {
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> exceptionHandler(MethodArgumentNotValidException ex) {
		Map<String, String> map = new HashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(e -> {
			map.put(e.getField(), e.getDefaultMessage());
		});
		return map;
	}

	@ExceptionHandler(ResourceNotFoundEx.class)
	public Map<String, Object> userException(ResourceNotFoundEx ex) {
		Map<String, Object> map = new HashMap<>();
		map.put("Status", HttpStatus.NOT_FOUND);
		map.put("message", ex.getMessage());
		map.put("Success", false);
		return map;
	}

	@ExceptionHandler(NonZeroException.class)
	public ResponseEntity<Ratingexception> notNullException(NonZeroException ex) {
		Ratingexception error = new Ratingexception(HttpStatus.NOT_ACCEPTABLE.value(), ex.getMessage());
		return new ResponseEntity<Ratingexception>(error, HttpStatus.NOT_ACCEPTABLE);

	}
}
