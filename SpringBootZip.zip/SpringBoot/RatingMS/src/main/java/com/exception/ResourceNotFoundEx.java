package com.exception;

public class ResourceNotFoundEx extends RuntimeException{

	public ResourceNotFoundEx() {
		super("Resource Not Found");
	}

	public ResourceNotFoundEx(String message) {
		super(message);
	}
	
	

}
