package com.exception;

public class NonZeroException extends RuntimeException{

	public NonZeroException() {
		super("Value Should not be zero or negative");
	}

	public NonZeroException(String message) {
		super(message);
	}

	

}
