package com.exception;

public class Ratingexception {
	
	private int errorId;
	private String errorMessage;
	public int getErrorId() {
		return errorId;
	}
	public void setErrorId(int errorId) {
		this.errorId = errorId;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	
	public Ratingexception() {
		super();
	}
	public Ratingexception(int errorId, String errorMessage) {
		super();
		this.errorId = errorId;
		this.errorMessage = errorMessage;
	}
	@Override
	public String toString() {
		return "Ratingexception [errorId=" + errorId + ", errorMessage=" + errorMessage + "]";
	}
	
	
}
