package com.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "UserDetails")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "UserId")
	int userId;

	@Column(name = "UserName")
	@NotBlank(message = "UserName shouldn't be blank")
	@NotNull(message = "UserName shouldn't be null")
	String userName;

	@Column(name = "Email")
	@NotBlank(message = "Email shouldn't be blank")
	@NotNull(message = "Email shouldn't be null")
	String email;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public User() {
		super();
	}

	public User(int userId,
			@NotBlank(message = "UserName shouldn't be blank") @NotNull(message = "UserName shouldn't be null") String userName,
			@NotBlank(message = "Email shouldn't be blank") @NotNull(message = "Email shouldn't be null") String email) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.email = email;

	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", email=" + email + "]";
	}

}
