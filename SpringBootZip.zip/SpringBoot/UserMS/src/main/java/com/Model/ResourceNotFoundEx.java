package com.Model;

public class ResourceNotFoundEx extends RuntimeException{

	public ResourceNotFoundEx() {
		super("Resource Not Found Exception");
		// TODO Auto-generated constructor stub
	}

	public ResourceNotFoundEx(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
