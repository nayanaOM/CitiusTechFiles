package com.service;

import java.util.List;

import com.Model.Hotel;

public interface HotelService {
	Hotel saveHotel(Hotel hotel);
	List<Hotel> getAllHotels();
	Hotel getHotel(int id);
}
