package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Model.Hotel;
import com.Model.NotNullException;
import com.Model.ResourceNotFound;
import com.repository.HotelRepository;

@Service
public class HotelServiceImpl implements HotelService {

	@Autowired
	HotelRepository hotelRepository;

	@Override
	public Hotel saveHotel(Hotel hotel) {
		if (hotel.getLocation() == null) {
			throw new NotNullException();
		} else {
			return hotelRepository.save(hotel);
		}
	}

	@Override
	public List<Hotel> getAllHotels() {
		return hotelRepository.findAll();
	}

	@Override
	public Hotel getHotel(int id) {
		return hotelRepository.findById(id).orElseThrow(() -> new ResourceNotFound("Invalid Input"));
	}

	public List<Hotel> getHotelByName(String name) {
		List<Hotel> list = hotelRepository.findByName(name);
		if (list.isEmpty()) {
			throw new ResourceNotFound();
		} else {
			return list;
		}
	}

	public List<Hotel> getHotelByLocation(String location) {
		List<Hotel> list = hotelRepository.getHotelLocation(location);
		if (list.isEmpty()) {
			throw new ResourceNotFound();
		} else {
			return list;
		}
	}
}
