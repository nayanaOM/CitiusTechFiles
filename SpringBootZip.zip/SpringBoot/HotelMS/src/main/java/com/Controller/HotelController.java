package com.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Model.Hotel;
import com.Model.NotNullException;
import com.Model.ResourceNotFound;
import com.service.HotelServiceImpl;

import jakarta.validation.Valid;

@RestController
//@Controller is used to declare common web controllers which can return HTTP response.
//@RestController is used to create controllers for REST APIs which can return JSON.
     //Spring RestController takes care of mapping request data to the defined request handler method.
public class HotelController {

	@ExceptionHandler(ResourceNotFound.class)
	public ResponseEntity<Map<String, Object>> exceptionHandler(ResourceNotFound ex) {
		Map<String, Object> map = new HashMap<>();
		map.put("message", ex.getMessage());
		map.put("success", false);
		map.put("status", HttpStatus.SC_NOT_FOUND);

		return new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.SC_NOT_FOUND);
	}

	@ExceptionHandler(NotNullException.class)
	public String exceptionHandler1(NotNullException ex) {
		return ex.getMessage();
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String, String>> exceptionHandler(MethodArgumentNotValidException ex) {
		Map<String, String> map = new HashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(e -> {
			map.put(e.getField(), e.getDefaultMessage());
		});
		return new ResponseEntity<Map<String, String>>(map, null, HttpStatus.SC_NOT_ACCEPTABLE);

	}

	@Autowired
	HotelServiceImpl hotelServiceImpl;

	@PostMapping("/addHotel")
	public Hotel addHotel(@RequestBody @Valid Hotel hotel) {
		return hotelServiceImpl.saveHotel(hotel);
	}

	@GetMapping("/getHotels")
	public List<Hotel> listAllHotel() {
		return hotelServiceImpl.getAllHotels();
	}

	@GetMapping("/getHotel/{id}")
	public Hotel getHotel(@PathVariable int id) {
		return hotelServiceImpl.getHotel(id);
	}

	@GetMapping("/getHotelByName/{name}")
	public List<Hotel> ListHotelByName(@PathVariable String name) {
		return hotelServiceImpl.getHotelByName(name);
	}

	@GetMapping("/getHotelByLocation/{location}")
	public List<Hotel> ListHotelByLocation(@PathVariable String location) {
		return hotelServiceImpl.getHotelByLocation(location);
	}
}
