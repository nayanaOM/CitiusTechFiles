package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.Model.Hotel;

@Repository
public interface HotelRepository extends JpaRepository<Hotel, Integer> {
//	@Query(value = "select * from hotel_details where hotel_name=?",nativeQuery = true)
//	List<Hotel> getHotelByName(String name);

	List<Hotel> findByName(String name);

	@Query(value = "select * from hotel_details h where h.hotel_location=?", nativeQuery = true)
	List<Hotel> getHotelLocation(String location);
}
