package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelMsApplication.class, args);
	}
//	hotel : HotelRepository: @query not working
// rating : vaidator for id is not working
// user :   getalluser :ratings are not displaying,
//		    getting 500 error for all userid except userid:1

}
