package com.Model;

public class NotNullException extends RuntimeException{

	public NotNullException() {
		super("Value Should not be null");
	}

	public NotNullException(String message) {
		super(message);
	}

	

}
