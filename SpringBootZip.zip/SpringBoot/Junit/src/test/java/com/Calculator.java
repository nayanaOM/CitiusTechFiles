package com;

public class Calculator {
	public int doSum(int a,int b) {
		return a+b;
		
	}
	public float doMul(int a,int b) {
		return a*b;
		
	}
	public int doDiv(int a,int b) {
		return a/b;
	}
	public boolean compare(int a,int b) {
		return a==b;
	}
}
