package com;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JunitApplicationTests {

	Calculator c = new Calculator();
	
	@Test
	@Disabled
	void contextLoads() {
	}

	@Test
	void testDoSum() {
		int expected=20;
		int actual = c.doSum(10, 10);
		
		assertThat(actual).isEqualTo(expected);
	}
	
	@Test
	void testCompareTwoNmber() {
	
		boolean actualValue=c.compare(4, 4);
		assertThat(actualValue).isTrue();		
	}
}
