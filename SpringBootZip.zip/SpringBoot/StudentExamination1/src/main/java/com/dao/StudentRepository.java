package com.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.model.Student;

public interface StudentRepository extends CrudRepository<Student, Integer> {

	public Student findByFname(String fname );
	
}
