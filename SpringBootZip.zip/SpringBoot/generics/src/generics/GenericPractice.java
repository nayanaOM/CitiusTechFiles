package generics;

class Numbers<T>{
	
	public void add(T t) {
		System.out.println(t);
	}

}
public class GenericPractice {
	public static void main(String[] args) {
		Numbers<Integer> g = new Numbers<Integer>();
		Numbers<Float> g1 = new Numbers<Float>();
		
		g.add(new Integer(19));
		g1.add(new Float(22.9));
		
	}
}
