package com;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	
	@Autowired
	CityRepository cityRepository;
	
	@GetMapping("/city/{country}")
	public List<City>  getCountry(@PathVariable("country") String country) {
		List<City> list = cityRepository.findByCountry(country);
		return list;
		
	}
	
	@PostMapping("/add")
	public void add(@RequestBody City c) {
		System.out.println("nkjk");
		City c1 = new City(c.getCountry(),c.getCity_name(),c.getCity_desc());
		cityRepository.save(c1);
	}

}
