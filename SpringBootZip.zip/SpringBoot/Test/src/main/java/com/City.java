package com;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="city")
public class City {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int city_id;
	private String country;
	private String city_name;
	private String city_desc;
	public int getCity_id() {
		return city_id;
	}
	public void setCity_id(int city_id) {
		this.city_id = city_id;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCity_name() {
		return city_name;
	}
	public void setCity_name(String city_name) {
		this.city_name = city_name;
	}
	public String getCity_desc() {
		return city_desc;
	}
	public void setCity_desc(String city_desc) {
		this.city_desc = city_desc;
	}
	public City( String country, String city_name, String city_desc) {
		super();
		this.country = country;
		this.city_name = city_name;
		this.city_desc = city_desc;
	}
	@Override
	public String toString() {
		return "City [city_id=" + city_id + ", country=" + country + ", city_name=" + city_name + ", city_desc="
				+ city_desc + "]";
	}
	public City() {
		super();
	}
	
	
}
