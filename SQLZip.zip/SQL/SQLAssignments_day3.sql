-- DAY3

-- 1.	Write a query to determine the number of customers in the Sales.Customer table.  

SELECT COUNT(CustomerID) AS [NUM OF CUSTOMERS] FROM Sales.Customer

-- 2.	Write a query using the Production.Product table that displays the minimum, maximum, and average ListPrice. 

SELECT MIN(ListPrice) AS min, MAX(ListPrice) AS max, avg(ListPrice) AS avg FROM Production.Product

-- 3.	Write a query that shows the total number of items ordered for each product. Use the Sales.SalesOrderDetail table to
--write the query. 

SELECT ProductID,SUM(OrderQty) AS TOTAL FROM Sales.SalesOrderDetail GROUP BY ProductID

-- 4.	Write a query using the Sales.SalesOrderDetail table that displays a count of the detail lines for each SalesOrderID. 

SELECT SalesOrderID,COUNT(LineTotal) AS [COUNT] FROM Sales.SalesOrderDetail GROUP BY SalesOrderID

-- 5.	Write a query using the Production.Product table that lists a count of the products in each product line.

SELECT ProductLine,COUNT(ProductID) AS Count FROM Production.Product GROUP BY ProductLine

-- 6.	Write a query that displays the count of orders placed by year for each customer using the Sales.SalesOrderHeader table. 

SELECT CustomerID,YEAR(OrderDate) AS Year,
COUNT(SalesOrderID) OVER(PARTITION BY OrderDate) AS [COUNT OF ORDER PLACED] FROM Sales.SalesOrderHeader 

-- 7.	Write a query that creates a sum of the LineTotal in the Sales.SalesOrderDetail table grouped by the SalesOrderID. 
--Include only those rows where the sum exceeds 1,000.  

SELECT SUM(LineTotal) AS Sum FROM Sales.SalesOrderDetail GROUP BY SalesOrderID
HAVING SUM(LineTotal)>1000

-- 8.	Write a query that groups the products by ProductModelID along with a count. Display the rows that have a count that equals 1.

SELECT ProductModelID,COUNT(ProductModelID) AS Count FROM Production.ProductModel GROUP BY ProductModelID
HAVING COUNT(ProductModelID)=1

-- 9.	Write a query using the Sales.SalesOrderHeader, Sales.SalesOrderDetail, and Production.Product tables to display the total sum of
-- products by ProductID and OrderDate.

SELECT COUNT(P.ProductID) SumOfOrderQty, SOH.OrderDate
FROM Sales.SalesOrderHeader AS SOH
INNER JOIN Sales.SalesOrderDetail AS SOD
ON SOH.SalesOrderID = SOD.SalesOrderDetailID
INNER JOIN Production.Product AS P 
ON SOD.ProductID = P.ProductID
GROUP BY P.ProductID, SOH.OrderDate;

-- 10.	Display the 3rd joined employee. 

SELECT * FROM (
SELECT FirstName,
DENSE_RANK()OVER(ORDER BY HireDate) AS RNK
FROM HumanResources.Employee AS HR
LEFT OUTER JOIN Person.Person AS PP
ON HR.BusinessEntityID = PP.BusinessEntityID
)AS t WHERE RNK=3

-- 11.	Display the customer who has placed 2nd highest orders
SELECT * FROM (
SELECT PP.FirstName,OrderQty,
DENSE_RANK()OVER(ORDER BY OrderQty DESC) AS RNK 
FROM Person.Person AS PP LEFT OUTER JOIN Sales.Customer AS SC
ON PP.BusinessEntityID = SC.PersonID
INNER JOIN Sales.SalesOrderHeader AS SOH
ON SOH.CustomerID = SC.CustomerID
INNER JOIN Sales.SalesOrderDetail SOD
ON SOD.SalesOrderID = SOH.SalesOrderID
) AS T1 WHERE RNK=2;

-- 12.	Display top 25% of costliest products in every subcategory
SELECT * FROM (
SELECT PP.Name AS PRODUCT_NAME,psc.Name,ProductID,StandardCost,
NTILE(4)OVER(PARTITION BY PSC.Name ORDER BY StandardCost DESC) AS RNK
FROM Production.Product AS PP
LEFT OUTER JOIN Production.ProductSubcategory AS PSC
ON PP.ProductSubcategoryID = PSC.ProductSubcategoryID
)AS tab WHERE RNK=1

-- 13.	Create a sequence to be used in two different temporary tables (Note: create temporary tables if required)
CREATE SEQUENCE SEQ1 AS INT
START WITH 100
INCREMENT BY 5
MAXVALUE 5000
MINVALUE 10
NO CYCLE
CACHE 25

CREATE TABLE TAB1
(
T1ID INT,
NAME VARCHAR(10)
);

CREATE TABLE TAB2
(
T2ID INT,
NAME VARCHAR(10)
);
INSERT INTO TAB1 VALUES(NEXT VALUE FOR S1,'NAYANA')
INSERT INTO TAB1 VALUES(NEXT VALUE FOR S1,'MEGHANA')
INSERT INTO TAB1 VALUES(NEXT VALUE FOR S1,'KAVANA')
SELECT * FROM TAB1
INSERT INTO TAB2 VALUES(NEXT VALUE FOR S1,'SAHANA')
INSERT INTO TAB2 VALUES(NEXT VALUE FOR S1,'JYOTI')
INSERT INTO TAB2 VALUES(NEXT VALUE FOR S1,'AYESHA')
SELECT * FROM TAB2


