-- 1.	Create a procedure that takes a string parameter. The input string may be a string or a numeric or NULL value. Convert the string 
-- to Integer. If it cannot be converted write an exception handling section to handle the appropriate error. If the string is converted
-- to integer print Hello the input integer number of times
drop PROCEDURE pr1

CREATE PROCEDURE pr1
(
@str VARCHAR(20)
)
AS
BEGIN 
DECLARE @R INT

	BEGIN TRY

	SET @R = CONVERT(INT,@str)
	WHILE(@R>0)
	BEGIN 
		print 'Hello'
	SET @R = @R - 1
	END

	END TRY

	BEGIN CATCH
 
	IF ERROR_NUMBER() = 245
		PRINT 'Unable to convert string to integer'
	END CATCH

END 

EXECUTE dbo.Pr1 '8';
EXECUTE dbo.Pr1 'SOUMYA';
EXECUTE dbo.Pr1 'NULL';

-- 2.	Create a temp table to represent employees. Design a user defined exception to handle the salary input less than 10000. 

CREATE TABLE EMP
(
empID INT PRIMARY KEY,
empName VARCHAR(20),
salary MONEY 
)

SELECT * FROM EMP

BEGIN TRY
DECLARE @SAL MONEY
	INSERT INTO EMP VALUES (101,'Nayana',200000)
	INSERT INTO EMP VALUES (102,'KAVANA',5000)
	INSERT INTO EMP VALUES (103,'megha',8000)

	SELECT @SAL=salary FROM EMP WHERE empID=10
	
	IF  @SAL < 10000
		THROW 50001, 'SALARY CANNOT BE LESSTHAN 10000',1;
END TRY

BEGIN CATCH
	PRINT ERROR_MESSAGE()
END CATCH

-- 3.	Write a cursor to fetch top 10 costliest products

select * from Production.Product

create table #costly
(
	ProductName varchar(255),
	ProductCost int
)

declare showCostliest cursor
scroll
for
SELECT TOP (10)
P.Name , P.StandardCost 
FROM Production.Product P
ORDER BY P.StandardCost DESC;
declare @pname varchar(20),@pc int
open showCostliest
fetch next from ShowCostliest into @pname, @pc

while @@FETCH_STATUS = 0
	begin
		insert into #costly values (@pname,@pc)
		fetch next from showCostliest into @pname , @pc
	end

select * from #costly
close showCostliest
deallocate showCostliest

drop table #costly

-- 4.	Document your understanding and possible solutions to Deadlock concept [Hint: You may explore online]

A deadlock occurs when two or more tasks permanently block one another because each task has a lock on a resource the 
other task is trying to lock. A deadlock is also called a cyclic dependency: in the case of a two-task deadlock,
transaction A has a dependency on transaction B, and transaction B closes the circle by having a dependency on 
transaction A.
deadlocks may still occur in databases because:
1. Queries that modify data may block one another.
2. Queries may run under isolation levels that increase blocking. 
3. Isolation levels may be specified via client library methods, query hints, or SET statements in Transact-SQL.

