-- DAY 5

-- 1.	Write a procedure to insert data in Patient and PatientAddress tables using input parameters 
-- [PatientID is an Identity column in Patient table and PatientAddress table is related to Patient table]

CREATE TABLE Patient
(
PatientID INT PRIMARY KEY,
PatientName VARCHAR(20),
Gender VARCHAR(1),
);

CREATE TABLE PatientAddress
(
PatientID INT REFERENCES Patient(PatientID) ,
P_Address VARCHAR(50)
);

CREATE PROCEDURE p1
(
@PatientID INT,
@PatientName VARCHAR(20),
@Gender VARCHAR(1),
@P_Address VARCHAR(50)
)
AS 
BEGIN 
	INSERT INTO Patient VALUES (@PatientID,@PatientName,@Gender) 
	PRINT 'PATIENT RECORDS INSERTED...'

	INSERT INTO PatientAddress VALUES (@PatientID,@P_Address) 
	PRINT 'PATIENT ADDRESS INSERTED...'
END
EXECUTE dbo.P1 1,'SOUMYA','F','JSDJKAHSLKAJFL';
EXECUTE dbo.P1 2,'RAM','M','IYUSDGSJ';
EXECUTE dbo.P1 3,'SITA','F','KASJAKJDKHS';

SELECT * FROM Patient
SELECT * FROM PatientAddress


-- 2.	An input string representing passenger data comes in a below format to a procedure. Extract the data from the string 
--and store in a temporary table. String format: �[P9001,John Roy,Male,12-Jan-2009]�

create table #Tab
(
ID varchar(10),
name varchar(15),
gender varchar(10),
dob varchar(15) 
)

create procedure pro
(
@String varchar(50),
@one varchar(10)=null,
@two varchar(10)=null,
@three varchar(10)=null,
@four varchar(15)=null
)as
begin
set @one =substring(@String,0,PATINDEX('%,%',@String))
set @String =substring(@String,len(@one+',')+1,len(@String))

set @two =substring(@String,0,PATINDEX('%,%',@String))
set @String =substring(@String,len(@two+',')+1,len(@String))

set @three =substring(@String,0,PATINDEX('%,%',@String))
set @String =substring(@String,len(@three+',')+1,len(@String))

set @four=@String

insert into #Tab(ID,name,gender,dob) values (@one,@two,@three,@four)

select * from #Tab
PRINT @one;
PRINT @two;
PRINT @three;
PRINT @four;
print 'inserted!'
end;

execute pro 'P9001,John Roy,Male,12-Jan-2009';


-- 3.	Modify the Day 5 - Lab 2 to validate the below
-- 1.	No duplicate entry for a passenger must be attempted to insert in table
-- 2.	The Age of the passenger must be between 6 to 90 

create table #Tab
(
ID varchar(10) PRIMARY KEY,
name varchar(15),
gender varchar(10),
dob DATE check( YEAR(GETDATE())  - year(dob) between 6 and 90)  
)
SELECT * FROM #Tab

create procedure pro1
(
@String varchar(50),
@one varchar(10)=null,
@two varchar(10)=null,
@three varchar(10)=null,
@four varchar(15)=null
)as
begin
set @one =substring(@String,0,PATINDEX('%,%',@String))
set @String =substring(@String,len(@one+',')+1,len(@String))

set @two =substring(@String,0,PATINDEX('%,%',@String))
set @String =substring(@String,len(@two+',')+1,len(@String))

set @three =substring(@String,0,PATINDEX('%,%',@String))
set @String =substring(@String,len(@three+',')+1,len(@String))

set @four=@String

insert into #Tab(ID,name,gender,dob) values (@one,@two,@three,@four)

select * from #Tab
PRINT @one;
PRINT @two;
PRINT @three;
PRINT @four;
print 'inserted!'
end;

execute pro 'P9001,John Roy,Male,12-Jan-2009';
execute pro 'P9002,mary,female,15-nov-2008';

