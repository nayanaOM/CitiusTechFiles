CREATE SCHEMA HR
CREATE TABLE HR.Employee
(
EmpID INT,
EmpName VARCHAR(20),
Gender VARCHAR(1),
DOB DATE,
PhNo VARCHAR(10),
Designation VARCHAR(20)
);

INSERT INTO Employee VALUES
(101,'Nayana','F','26-April-2000',7618665564,'Software Engineer')

INSERT INTO Employee VALUES
(102,'Sahana','F','05-Dec-2000',8632866564,'Software Engineer')

INSERT INTO Employee VALUES
(103,'kavana','F','6-April-2000',9846665564,'Software Engineer'),
(104,'meghana','F','6-Nov-2000',9876565564,'Software Engineer')

DELETE FROM Employee where EmpID=103;

INSERT INTO Employee VALUES
(103,'bhavana','F','8-Jun-2000',8917665564,'Software Engineer'),
(105,'meghana','F','4-May-2000',9267265564,'Software Engineer')

INSERT INTO Employee(EmpID,EmpName,Gender) VALUES
(106,'Geeta','F')

SELECT * FROM Employee;
SELECT EmpID,EmpName FROM Employee;