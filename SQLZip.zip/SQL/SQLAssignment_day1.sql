CREATE SCHEMA Sales
CREATE SCHEMA Person
CREATE SCHEMA HumanResources
CREATE SCHEMA Production

CREATE TABLE Sales.Country
(
  countryID INT PRIMARY KEY IDENTITY(101,1),
  countryName VARCHAR(20) DEFAULT 'INDIA'
);
CREATE TABLE Sales.Territory
(
  territoryID INT PRIMARY KEY IDENTITY,
  territoryName VARCHAR(20),
  countryID INT REFERENCES Sales.Country(countryID)
);

CREATE TABLE Person.Person
(
  personID INT PRIMARY KEY IDENTITY(101,1),
  Title VARCHAR(20),
  FirtName VARCHAR(20) NOT NULL,
  MiddleName VARCHAR(20),
  LastName VARCHAR(20),
  Gender VARCHAR(1) CHECK(Gender IN('M','F','O')),
  modifiedDate DATE,
);

CREATE TABLE Sales.Customer
(
 customerID INT PRIMARY KEY IDENTITY(1001,1), 
 personID INT REFERENCES Person.Person(personID),
 territoryID INT REFERENCES Sales.Territory(territoryID),
 customerGrade VARCHAR(1)
);


CREATE TABLE HumanResources.Department
(
  departmentID INT PRIMARY KEY IDENTITY(01,1), 
  departmentName VARCHAR(20),
);
CREATE TABLE HumanResources.Employee
(
  employeeID INT PRIMARY KEY IDENTITY,
  Designation VARCHAR(20),
  managerID INT UNIQUE,
  dateOfJoining DATE,
  departmentID INT REFERENCES HumanResources.Department(departmentID),
  personID INT REFERENCES Person.Person(personID)
);
CREATE TABLE Sales.SalesOrderHeader
(
  salesOrderHeaderID INT PRIMARY KEY IDENTITY,
  orderDate DATE,
  customerID INT REFERENCES Sales.Customer(customerID),
  salesPersonID INT REFERENCES HumanResources.Employee(EmployeeID)
);

CREATE TABLE Sales.SalesOrderDetail
(
  salesOrderDetailID INT PRIMARY KEY IDENTITY,
  salesOrderHeaderID INT REFERENCES Sales.SalesOrderHeader(salesOrderHeaderID),
  orderDate DATE,
  productID INT REFERENCES Production.Product(productID),
  orderQuantity INT
);

CREATE TABLE Production.ProductCategory
(
 productCategoryID INT PRIMARY KEY IDENTITY(101,1),
 productCategoryName VARCHAR(20) 
);

CREATE TABLE Production.ProductSubCategory
(
 ProductSubCategoryID INT PRIMARY KEY IDENTITY(101,1),
 ProductSubCategoryName VARCHAR(20),
 ProductCategoryID INT REFERENCES Production.ProductCategory(ProductCategoryID) 
);
CREATE TABLE Production.Product
(
 ProductID INT PRIMARY KEY IDENTITY(101,1),
 ProductName VARCHAR(20),
 ProductCost INT,
 quantityInStock INT,
 ProductSubCategoryID INT REFERENCES Production.ProductSubCategory(ProductSubCategoryID) 
);

