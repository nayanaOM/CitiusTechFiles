SELECT  Gender, COUNT(*)OVER(PARTITION BY Gender)AS[COUNT]  FROM HumanResources.Employee 

SELECT  Gender, COUNT(Gender)AS[COUNT]  FROM HumanResources.Employee GROUP BY Gender

SELECT HireDate, DENSE_RANK()OVER(ORDER BY HireDate) AS[RNK] FROM HumanResources.Employee