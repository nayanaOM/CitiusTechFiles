-- DAY4

-- 1.	The HumanResources.Employee table does not contain the employee names. Join that table to the Person.Person 
-- table on the BusinessEntityID column. Display the job title, birth date, first name, and last name.

SELECT JobTitle,BirthDate,FirstName,LastName
FROM Person.Person PP
JOIN HumanResources.Employee HE
ON PP.BusinessEntityID = HE.BusinessEntityID

-- 2.	The customer names also appear in the Person.Person table. Join the Sales.Customer table to the Person.Person table. 
--The BusinessEntityID column in the Person.Person table matches the PersonID column in the Sales.Customer table. Display 
--the CustomerID, StoreID, and TerritoryID columns along with the name columns. 

SELECT CustomerID,StoreID,TerritoryID,FirstName,LastName FROM Person.Person PP
JOIN Sales.Customer SC
ON PP.BusinessEntityID = SC.PersonID

-- 3.	Write a query that joins the Sales.SalesOrderHeader table to the Sales. SalesPerson table. Join the BusinessEntityID
--column from the Sales.SalesPerson table to the SalesPersonID column in the Sales.SalesOrderHeader table. Display the
--SalesOrderID along with the SalesQuota and Bonus.  

SELECT SalesOrderID,SalesQuota,Bonus 
FROM Sales.SalesOrderHeader SOH 
JOIN Sales. SalesPerson SP
ON SOH.SalesPersonID = SP.BusinessEntityID

-- 4.	The catalog description for each product is stored in the Production.ProductModel table. Display the columns that 
-- describe the product from the Production.Product table, such as the color and size along with the catalog description 
--for each product.  

SELECT PP.NAME,Color,Size,CatalogDescription 
FROM Production.Product PP 
JOIN Production.ProductModel PM
ON PP.ProductModelID = PM.ProductModelID

-- 5.	Write a query that displays the names of the customers along with the product names that they have purchased.
--Hint: Five tables will be required to write this query!  

SELECT PP.FirstName,PP.MiddleName,PP.LastName
FROM Person.Person AS PP
LEFT OUTER JOIN Sales.Customer AS SC ON
PP.BusinessEntityID=SC.PersonID
JOIN Sales.SalesOrderHeader AS SOH ON
SC.CustomerID=SOH.CustomerID
JOIN Sales.SalesOrderDetail AS SOD ON
SOD.SalesOrderID=SOH.SalesOrderID
JOIN Production.Product AS PRP ON
PRP.ProductID=SOD.ProductID

-- 6.	Write a query that displays all the products along with the SalesOrderID even if an order has never been placed
--for that product. Join to the Sales.SalesOrderDetail table using the ProductID column. 

SELECT BusinessEntityID,SalesOrderID,OrderQty 
FROM Person.Person PP 
LEFT OUTER JOIN Sales.SalesOrderDetail SOD
ON PP.BusinessEntityID = SOD.ProductID

-- 7.  The Sales.SalesOrderHeader table contains foreign keys to the Sales.CurrencyRate and Purchasing.ShipMethod tables. 
--Write a query joining all three tables, making sure it contains all rows from Sales.SalesOrderHeader. Include the
--CurrencyRateID, AverageRate, SalesOrderID, and ShipBase columns.  

SELECT CR.CurrencyRateID,AverageRate,SalesOrderID,ShipBase
FROM Sales.CurrencyRate CR  
RIGHT OUTER JOIN Sales.SalesOrderHeader SOH
ON SOH.CurrencyRateID=CR.CurrencyRateID
LEFT OUTER JOIN Purchasing.ShipMethod SM
ON SOH.ShipMethodID = SM.ShipMethodID

-- 8.	Get all the order details to gererate a report that displays, OrderID, OrderNumber, OrderDate, Shipping Date and 
--the product names, subcategory and category which are the part of that order and include the name of customer who has
--placed the order as well as the name of territory and country from where order has been placed [Hint: Identify the correct 
--set of related tables]

SELECT SOH.SalesOrderID,RevisionNumber,OrderDate,ShipDate,PP.Name [CUSTOMER NAME],PSC.Name [SUB CATEGORY NAME],
PC.Name [CATEGORY NAME] 
FROM Sales.CountryRegionCurrency CRC
RIGHT OUTER JOIN Sales.SalesTerritory ST
ON CRC.CountryRegionCode = ST.CountryRegionCode
RIGHT OUTER JOIN Sales.Customer SC
ON SC.TerritoryID = ST.TerritoryID
RIGHT OUTER JOIN Person.Person AS PRN
ON SC.PersonID = PRN.BusinessEntityID
JOIN HumanResources.Employee HD
ON PRN.BusinessEntityID = HD.BusinessEntityID
JOIN Sales.SalesOrderHeader SOH
ON HD.BusinessEntityID = SOH.SalesPersonID
JOIN Sales.SalesOrderDetail SOD
ON SOH.SalesOrderID = SOD.SalesOrderID
JOIN Production.Product PP
ON SOD.ProductID = PP.ProductID
JOIN Production.ProductSubcategory PSC
ON PP.ProductSubcategoryID = PSC.ProductSubcategoryID
JOIN Production.Productcategory PC
ON PC.ProductCategoryID = PSC.ProductCategoryID

-- 9.	Get the Youngest Employee

select * from(
SELECT HRE.BusinessEntityID,PP.FirstName,PP.MiddleName,PP.LastName,hre.BirthDate, DENSE_RANK()
over(order by hre.BirthDate desc) as rnk
FROM HumanResources.Employee AS HRE
INNER JOIN Person.Person AS PP ON
PP.BusinessEntityID=HRE.BusinessEntityID
) as t where rnk=1

-- 10.	Create a temp. table and copy the data form Production.Product table (only red colored products) in the temp.
--table [Hint: use subquery]

SELECT ProductID,Name,ProductNumber,Color INTO TABLE2
FROM Production.Product WHERE Color = 'red'
select * from TABLE2

