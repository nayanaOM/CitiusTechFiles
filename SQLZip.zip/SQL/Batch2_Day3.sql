SELECT 
	SQRT(25) AS [SquareRoot],
	POWER(5,4) AS [POW],
	CEILING (12.00001) AS [C],
	FLOOR (12.99999) AS [F],
	ROUND (12.0999,2)AS [R]

SELECT ProductID,Name, ROUND(StandardCost,0) AS [StdCost]
FROM Production.Product 

-----STRING FUNCTIONS
SELECT UPPER('hello'), LOWER('JAne'),LEN('Karan Singh')

SELECT SUBSTRING ('RRR is directed by Rajamauli',1,5)

------DATETIME
SELECT GETDATE(), YEAR(GETDATE())

SELECT DATEDIFF(MI,'01-Jan-1956',GETDATE())

SELECT BusinessEntityID,JobTitle,BirthDate,HireDate,Gender,
MaritalStatus, DATEDIFF(YY,BirthDate,GetDate()) AS [Age],
DATEDIFF(YY,HireDate,GetDate()) AS [ExpInYears]
FROM HumanResources.Employee


SELECT DATEADD(MM,10,GETDATE())
-------------------------------------------------
SELECT ProductID,Name,Color,StandardCost
FROM Production.Product WHERE Name LIKE '%Crank%'
---------
--SORTING (ORDER BY)
SELECT ProductID,Name,Color,StandardCost
FROM Production.Product ORDER BY Name DESC

SELECT ProductID,Name,Color,StandardCost
FROM Production.Product ORDER BY StandardCost DESC

SELECT ProductID,Name,Color,StandardCost
FROM Production.Product 
ORDER BY StandardCost DESC, Name

-----------------------
SELECT ProductID,Name,ISNULL(Color,'undefined') AS [clr],
StandardCost
FROM Production.Product 

SELECT '1'+'Raj'

SELECT CONCAT(1,'Raj','1','jkljlkjl','fgfsdsads')

------------------------------------------------------
--Aggregate functs
SELECT Color,SUM(StandardCost) AS [TotalCost] 
FROM Production.Product

--colorwise cost of prods.
SELECT Color, SUM(StandardCost) AS [TotalCost] 
FROM Production.Product
GROUP BY Color

--colorwise count of products having cost >40 
SELECT Color, SUM(StandardCost) AS [TotalCost],
COUNT(*) AS [Count]
FROM Production.Product
GROUP BY Color
HAVING COUNT(*)>40




SELECT ProductID,Name,Color,StandardCost, ProductSubcategoryID
FROM Production.Product ORDER BY StandardCost DESC





---OVER CLAUSE
--get total cost with all prod info
SELECT ProductID,Name,Color,StandardCost,
SUM(StandardCost)OVER() AS [TotalCost] 
FROM Production.Product


--get colorwise total cost with all prod info
SELECT ProductID,Name,Color,StandardCost,
SUM(StandardCost)OVER(PARTITION BY Color) AS [TotalCost] 
FROM Production.Product

/*
	ROW_NUMBER
	RANK
	DENSE_RANK
	NTILE
*/

SELECT ProductID,Name,Color,StandardCost,
ROW_NUMBER()OVER(ORDER BY StandardCost DESC) AS [RN],
RANK()OVER(ORDER BY StandardCost DESC) AS [RNK],
DENSE_RANK()OVER(ORDER BY StandardCost DESC) AS [D_RNK]
FROM Production.Product


SELECT ProductID,Name,Color,StandardCost,
DENSE_RANK()OVER(ORDER BY StandardCost DESC) AS [D_RNK]
FROM Production.Product

--Aggregate functs
SELECT Color,SUM(StandardCost) AS [TotalCost]
FROM Production.Product



--colorwise cost of prods.
SELECT Color, SUM(StandardCost) AS [TotalCost]
FROM Production.Product
GROUP BY Color



--colorwise count of products having cost >40
SELECT Color, SUM(StandardCost) AS [TotalCost],
COUNT(*) AS [Count]
FROM Production.Product
GROUP BY Color
HAVING COUNT(*)>40

-- INNER JOIN
SELECT FirstName,LastName FROM HumanResources.Employee AS HE INNER JOIN Person.Person AS PP
ON HE.BusinessEntityID = PP.BusinessEntityID


--LEFT OUTER JOIN
SELECT HE.BusinessEntityID,FirstName,LastName FROM Person.Person AS PP LEFT OUTER JOIN HumanResources.Employee AS HE
ON HE.BusinessEntityID = PP.BusinessEntityID

-- JOINING MULTIPLE TABLES 
SELECT SOH.SalesOrderID,OrderDate,TerritoryID,SOD.ProductID,SOD.SalesOrderDetailID,PP.Name AS ProductcategoryName, PSC.Name AS ProductSubcategoryName
FROM Sales.SalesOrderHeader AS SOH 
INNER JOIN Sales.SalesOrderDetail AS SOD
ON SOH.SalesOrderID = SOD.SalesOrderID
JOIN Production.Product as PP
ON SOD.ProductID = PP.ProductID
LEFT OUTER JOIN Production.ProductSubcategory AS PSC
ON PSC.ProductSubcategoryID = PP.ProductSubcategoryID

-- SUB QUERIES--
-- GET ALL PRODUCTS COSTING SAME AS PROD NUMBER 722
--SINGE ROW SUBQUERY
SELECT ProductID,Name,StandardCost,Color FROM Production.Product 
where Standardcost =
(
SELECT Standardcost FROM Production.Product WHERE 
ProductID = 722
)

--GET ALL THE PERSONS who have joined as employees with designation as design engineer
SELECT FirstName,BusinessEntityID FROM Person.Person
WHERE BusinessEntityID IN
(
SELECT BusinessEntityID FROM  HumanResources.Employee 
WHERE JobTitle = 'Design Engineer'
)

-- GET ALL PRODUCTS THAT BELONG TO CLOTHING CATEGORY
SELECT ProductID,Name FROM Production.Product
WHERE ProductSubcategoryID IN
(
SELECT ProductSubcategoryID FROM Production.ProductSubcategory
WHERE ProductcategoryID =
(
SELECT ProductCategoryID FROM Production.ProductCategory 
WHERE Name = 'Clothing'
)
)


---- GET ALL PRODUCTS COSTING SAME AS PROD NUMBER 722 AND 800
SELECT ProductID,Name,StandardCost,Color FROM Production.Product 
where Standardcost >ALL
(
SELECT Standardcost FROM Production.Product WHERE 
ProductID IN( 722,800)
)

---- GET ALL PRODUCTS COSTING SAME AS PROD NUMBER 722 OR 800
SELECT ProductID,Name,StandardCost,Color FROM Production.Product 
where Standardcost >ANY
(
SELECT Standardcost FROM Production.Product WHERE 
ProductID IN( 722,800)
)

-- GET ALL PRODUCTS ONLY IF THERE ARE PRODUCTS COSING MORE THAN 2000
SELECT * FROM Production.Product WHERE
EXISTS(
SELECT * FROM Production.Product where Standardcost > 2000
)


-- GET ALL PRODUCTS IF THERE IS NO PRODUCTS COSING MORE THAN 2000
SELECT * FROM Production.Product WHERE
NOT EXISTS(
SELECT * FROM Production.Product where Standardcost > 35000
)

--	Corelated Subquery
-- GET ALL PRODUCTS HAVING STANDARDCOST LESS THAN AVG STDCOST FOR IT'S ProductSubcategoryID
SELECT * FROM Production.Product AS PP WHERE StandardCost<
(
SELECT AVG(StandardCost) FROM Production.Product WHERE ProductSubcategoryID = PP.ProductSubcategoryID
)


CREATE TABLE FemaleEmp
(
EmpID INT,
Designation VARCHAR(50),
DOB DATE,
Gender VARCHAR(1)
)
INSERT INTO FemaleEmp
SELECT BusinessEntityID, JobTitle, BirthDate,Gender 
FROM HumanResources.Employee WHERE Gender='F'

SELECT * FROM FemaleEmp

--VIEWS 

CREATE VIEW V_1985 AS
SELECT * FROM FemaleEmp WHERE YEAR(DOB)>1985

SELECT * FROM V_1985

DELETE FROM FemaleEmp WHERE Designation = 'Marketing Specialist'
DELETE FROM V_1985 WHERE Designation = 'Application Specialist'

-- synonyms

CREATE SYNONYM P FOR Production.Product

SELECT * FROM P