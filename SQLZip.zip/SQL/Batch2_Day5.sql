--Get all prods costing same as prod no 722

SELECT ProductID,Name,StandardCost,Color FROM Production.Product 
WHERE StandardCost=
(
	SELECT StandardCost FROM Production.Product WHERE 
	ProductID = 722
)

--Get all prods in Brakes and Chains subcategory
SELECT ProductID,Name,StandardCost,Color, ProductSubcategoryID 
FROM Production.Product WHERE ProductSubcategoryID IN
(
	SELECT ProductSubcategoryID FROM Production.ProductSubcategory
	WHERE Name IN ('Brakes','Chains')
)

--get all the persons who have joined as employees 
--with designation as Design Engineer


--get all the products that belong to Clothing category


SELECT ProductID,Name,StandardCost,Color, ProductSubcategoryID 
FROM Production.Product WHERE ProductSubcategoryID IN
(
	SELECT ProductsubcategoryID FROM Production.ProductsubCategory
	WHERE productcategoryID =
	(
		SELECT ProductCategoryID FROM Production.ProductCategory
		WHERE Name = 'Clothing'
	)
)
-------------------------
--get all prods costing more than product no 722 and 800

SELECT ProductID,Name,StandardCost,Color, ProductSubcategoryID 
FROM Production.Product WHERE
StandardCost > ALL
(
	SELECT StandardCost FROM Production.Product WHERE ProductID IN (722,800)
)
--------------------------------------------------------
--Multi column
SELECT * FROM Production.Product WHERE 
NOT EXISTS
(
	SELECT * FROM Production.Product WHERE StandardCost>50000
)
---------
SELECT * from HumanResources.Employee

CREATE TABLE MaleEmp
(
	EmployeeID INT,
	Designation VARCHAR(50),
	DOB DATE,
	DOJ DATE,
	Gender VARCHAR(1)
)

INSERT INTO MaleEmp
SELECT BusinessEntityID, JobTitle, BirthDate, HireDate, Gender
FROM HumanResources.Employee WHERE Gender = 'M'

SELECT * FROM MaleEmp

--corelated subquery
SELECT * FROM PatientVisits;

--Get all the Visits having VisitTime greater than 
--Average VisiTime for it's VisitPurpose
SELECT * FROM PatientVisits AS PVO WHERE VisitTime >
(
	SELECT AVG(VisitTime) FROM PatientVisits WHERE VisitPurpose = PVO.VisitPurpose
);

--Get all the Products having standardCost lesss than 
--Average standardCost for it's ProductSubCategoryID
-----------------------------------------
/*
VIEW
*/
SELECT * FROM MaleEmp

ALTER VIEW V_After1985Born AS
SELECT EmployeeID,Designation,DOB,Gender FROM MaleEmp WHERE YEAR(DOB)>1985
WITh CHECK OPTION

SELECT * FROM V_After1985Born


/*SYNONYM*/


CREATE SYNONYM PRD FOR Production.Product

SELECT * FROM PRD;

DELETE FROM MaleEmp WHERE Designation = 'Marketing Specialist'

DELETE FROM V_After1985Born WHERE Designation = 'Application Specialist'

-------- SEQUENCE --------

CREATE SEQUENCE S1 AS INT
START WITH 100
INCREMENT BY 5
MAXVALUE 5000
MINVALUE 10
NO CYCLE
CACHE 25

CREATE TABLE T1
(
T1ID INT,
NAME VARCHAR(10)
);

CREATE TABLE T2
(
T2ID INT,
NAME VARCHAR(10)
);
INSERT INTO T1 VALUES(NEXT VALUE FOR S1,'NAYANA')
INSERT INTO T1 VALUES(NEXT VALUE FOR S1,'MEGHANA')
INSERT INTO T1 VALUES(NEXT VALUE FOR S1,'KAVANA')
SELECT * FROM T1
INSERT INTO T2 VALUES(NEXT VALUE FOR S1,'SAHANA')
INSERT INTO T2 VALUES(NEXT VALUE FOR S1,'JYOTI')
INSERT INTO T2 VALUES(NEXT VALUE FOR S1,'AYESHA')
SELECT * FROM T2

---variables---

DECLARE @BussEntID INT;
DECLARE @FName VARCHAR(50);
DECLARE @LName VARCHAR(50);
SET @BussEntID = 5;
SELECT @FName = FirstName,@LName = LastName
    FROM Person.Person WHERE BusinessEntityID = @BussEntID;
PRINT '===========================';
PRINT 'BUSINESS ENTITY ID: ' + CONVERT(VARCHAR(20),@BussEntID);
PRINT 'FIRST NAME:  ' + @FName;
PRINT 'LAST NAME:  ' + @LName;
PRINT '===========================';


DECLARE @BussEntID INT;
DECLARE @Name VARCHAR(50);
DECLARE @JobTitle VARCHAR(50);
SET @BussEntID = 5;

SELECT @Name = PP.FirstName + ' ' + pp.LastName,@JobTitle= JobTitle FROM Person.Person AS PP
JOIN HumanResources.Employee AS HE 
ON PP.BusinessEntityID = HE.BusinessEntityID
WHERE PP.BusinessEntityID = @BussEntID

PRINT 'NAME : ' + @Name
PRINT 'JobTitle  : ' + @JobTitle

DECLARE @Age INT;
SET @Age = 56;
IF @Age<0 OR @Age>100
    PRINT 'INVALID AGE!';
ELSE
BEGIN
    PRINT 'VALID AGE!';
    IF @Age >= 0 AND @Age <= 12
        PRINT 'Child.';
    ELSE IF @Age >= 13 AND @Age <= 20
        PRINT 'Teen.';
    ELSE IF @Age >= 21 AND @Age <= 50
        PRINT 'Adult.';
    ELSE IF @Age >= 51 AND @Age <= 100
        PRINT 'Sr. Citizen';
END;


DECLARE @MATHS INT
DECLARE @Science INT
DECLARE @Social INT
DECLARE @Kannada INT
DECLARE @English INT
DECLARE @TOTAL FLOAT
DECLARE @PER FLOAT;

SET @MATHS=79
SET @Science=97
SET @Social=92
SET @Kannada=91
SET @English=96

 IF @MATHS>=40 AND @Science>=40 AND @Social>=40 AND @Kannada>=40 AND @English>=40
	BEGIN
	PRINT 'STUDENT PASSED';
	SET @TOTAL =  @MATHS + @Science + @Social + @Kannada + @English
	SET @PER = @TOTAL/5
	
	PRINT @TOTAL
	PRINT @PER 

	END
ELSE 
	PRINT 'STUDENT FAILED'



	--DEMO 2:: WHILE LOOP to iterate through table not having seq. data
SELECT * FROM RedProducts

DECLARE @TotalRows INT;
SELECT @TotalRows = COUNT(*) FROM RedProducts;
DECLARE @RN INT = 1;
DECLARE @PName VARCHAR(50);
WHILE @RN<=@TotalRows
BEGIN
    SELECT @PName = Name FROM
    (
        SELECT Name, ROW_NUMBER()OVER(ORDER BY Name) AS [RowNum]
         FROM RedProducts
    ) AS T WHERE [RowNum] = @RN;
    PRINT @PName;
    SET @RN += 1;
END;

-- print currencycode and name in Sales.Currency

DECLARE @TotalRows1 INT;
SELECT @TotalRows1 = COUNT(*) FROM Sales.Currency;
DECLARE @RN1 INT = 1;
DECLARE @CurrencyCode VARCHAR(50);
DECLARE @Name1 VARCHAR(50);
WHILE @RN1<=@TotalRows1
BEGIN
    SELECT @CurrencyCode = CurrencyCode, @Name1 = Name FROM
    (
        SELECT Name,CurrencyCode, ROW_NUMBER()OVER(ORDER BY Name) AS [RowNum1]
         FROM Sales.Currency
    ) AS T WHERE [RowNum1] = @RN1;
    PRINT concat('CurrencyCode is : ',@CurrencyCode,'   --------   Name is : ',@Name1);
    SET @RN1 += 1;
END;


/*
CREATE a TABLE CessnaTrainees
(TraineeID PK, FirstName, LastName,Gender,BatchNo,RandomCode).
CREATE a SP to insert data in CessnaTrainees table
only if the data meets below requirements
1. FirstName and LastName must not be null
2. Gender must be either M or F
3. BatchNo must be either 1 or 2
4. RandomCode must be between 1 to 10
*/
CREATE TABLE Cessnabatch
(
TrainingID INT PRIMARY KEY,
FirstName VARCHAR(20),
LastName VARCHAR(20),
Gender VARCHAR(1),
BatchNo INT,
RandomCode INT
);

CREATE PROCEDURE St_Procedure26
(
@TrainingID INT,
@FirstName VARCHAR(20),
@LastName VARCHAR(20),
@Gender VARCHAR(1),
@BatchNo INT,
@RandomCode INT
)AS 
BEGIN
if @FirstName IS NOT NULL AND @LastName IS NOT NULL AND @Gender IN('M','F') AND @BatchNo IN(1,5) AND @RandomCode BETWEEN 1 AND 10
 BEGIN
	INSERT INTO Cessnabatch VALUES
        (@TrainingID,@FirstName,@LastName,@Gender,@BatchNo,@RandomCode);
		 PRINT 'Record Inserted!';
    END;
else 
	print 'invalid input'
END;

EXECUTE dbo.St_Procedure26 1,'Nayana','Mayar','F',5,4;
EXECUTE dbo.St_Procedure26 2,'Sahana','Mayar','F',1,5;
EXECUTE dbo.St_Procedure26 3,'Ayesha','Nadaf','F',1,3;

SELECT * FROM Cessnabatch


--DEMO 1:
--CREATE a funct that takes businessentityid as parameter and returns fullname of a person

CREATE FUNCTION ADDITION(@BusinessentityID INT,@FirstName VARCHAR(20),@LastName VARCHAR(20))RETURNS VARCHAR
AS
BEGIN
	DECLARE @Name VARCHAR(20);
    
	SELECT @Name = concat(@BusinessentityID,@FirstName,@LastName) 
	RETURN @Name;
END;
DROP FUNCTION ADDITION
PRINT dbo.ADDITION(7,'NAYANA','MAYAR')


CREATE FUNCTION AMSTRONG(@NUM1 INT)
RETURNS VARCHAR(30) AS
BEGIN
    
	DECLARE @R INT;
	DECLARE @R1 INT;
	DECLARE @TEMP INT;
	SET @TEMP = @NUM1
    DECLARE @res VARCHAR(30);
	SET @R1 = 0
    WHILE (@NUM1>0)
	BEGIN
	SET @R = @NUM1 % 10
	SET @R1 = (@R*@R*@R) + @R1
	SET @NUM1 = @NUM1 / 10
	END
	IF @R1 = @TEMP
        SET @res = CONCAT(@TEMP,' is  AMSTRONG');
    ELSE
        SET @res = CONCAT(@TEMP,' is not  AMSTRONG');
	RETURN @res;
END;

DROP FUNCTION AMSTRONG
PRINT dbo.AMSTRONG (123);
PRINT dbo.AMSTRONG (153);
	

---------------TRIGGERS-----------------------

SELECT BusinessEntityID,FirstName,LastName INTO MY_TABLE 
FROM Person.Person

CREATE TRIGGER TRG
ON MY_TABLE
AFTER UPDATE 
AS
BEGIN
	 INSERT INTO MY_TABLE_deletelog
    (FirstName,LastName)
    SELECT FirstName,LastName FROM deleted;
    PRINT 'Record/s deleted and log/s created!';
END

UPDATE MY_TABLE SET FirstName= 'Nayana' ,LastName = 'Mayar' WHERE BusinessEntityID=285

CREATE TABLE MY_TABLE_deletelog
(
    DeletedID INT PRIMARY KEY IDENTITY(1,1),
    FirstName VARCHAR(50),
    LastName VARCHAR(20),
    DeletedDate DATE DEFAULT GETDATE()
);

DELETE FROM MY_TABLE WHERE FirstName = 'Nayana';

SELECT * FROM MY_TABLE
SELECT * FROM MY_TABLE_deletelog

drop TRIGGER TRG

-----------------------------------------

CREATE TRIGGER TRG1
ON MY_TABLE
INSTEAD OF INSERT AS
BEGIN
	PRINT 'RECORD INSERTED ..........'
END

INSERT INTO MY_TABLE VALUES (23,'SAHANA','MAYAR') 