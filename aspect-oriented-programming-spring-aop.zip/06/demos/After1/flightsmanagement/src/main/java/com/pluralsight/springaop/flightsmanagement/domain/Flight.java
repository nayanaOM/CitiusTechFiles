package com.pluralsight.springaop.flightsmanagement.domain;

public class Flight {
	
	private String id;
	private String company;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

}
