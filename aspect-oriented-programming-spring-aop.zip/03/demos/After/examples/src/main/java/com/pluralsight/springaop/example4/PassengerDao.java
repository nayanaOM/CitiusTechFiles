package com.pluralsight.springaop.example4;

public interface PassengerDao {

	Passenger getPassenger(int id);

}