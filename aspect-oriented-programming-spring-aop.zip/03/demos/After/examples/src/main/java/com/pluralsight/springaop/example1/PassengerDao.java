package com.pluralsight.springaop.example1;

public interface PassengerDao {

	Passenger getPassenger(int id);

}