package com.pluralsight.springaop.example2;

public interface PassengerDao {

	Passenger getPassenger(int id);

}